<?php 
	
	$host='localhost';
	$username='steeve';
	$pass='SeCx328aXthRu';
	$db='online';

	$conn=mysqli_connect($host,$username,$pass,$db);

	if(!$conn) die("Connection refused").mysql_connect_error();
 ?>
