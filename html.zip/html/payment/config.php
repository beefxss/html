<?php
    // Blockonmics API stuff
    $apikey = "Ir5AQwZ1EXRykqJk0DVLFtECaNQ1q52NeC52FEb3dN4";
    $url = "https://www.blockonomics.co/api/";
    
    $options = array( 
        'http' => array(
            'header'  => 'Authorization: Bearer '.$apikey,
            'method'  => 'POST',
            'content' => '',
            'ignore_errors' => true
        )   
    );

    // Connection info
    $conn = mysqli_connect("localhost", "steeve", "SeCx328aXthRu", "paymenty"); // enter your info
?>
