-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 11, 2021 at 08:05 PM
-- Server version: 8.0.26-0ubuntu0.20.04.2
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'Psychedelics'),
(2, 'Dissociatives'),
(3, 'Prescription'),
(4, 'Stimulants'),
(5, 'Cannabis'),
(6, 'Opiates');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `p_id` int NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_image` varchar(300) NOT NULL,
  `qty` int NOT NULL,
  `price` int NOT NULL,
  `total_amount` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Drugs and Chemicals'),
(2, 'Counterfeit\r\n'),
(3, 'Services'),
(4, 'Fraud'),
(5, 'Carding'),
(6, 'Software & Malware ');

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE `customer_order` (
  `id` int NOT NULL,
  `uid` int NOT NULL,
  `pid` int NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_price` int NOT NULL,
  `p_qty` int NOT NULL,
  `p_status` varchar(100) NOT NULL,
  `tr_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_order`
--

INSERT INTO `customer_order` (`id`, `uid`, `pid`, `p_name`, `p_price`, `p_qty`, `p_status`, `tr_id`) VALUES
(1, 1, 2, 'PayPal Transfer', 300, 1, 'CONFIRMED', '1108277413'),
(2, 1, 73, '50x LSD Vendetta 250 microgram', 216, 1, 'CONFIRMED', '88909313'),
(3, 1, 39, '35g Lemon Haze', 302, 1, 'CONFIRMED', '1835796934'),
(4, 2, 36, '50 Adderalls B974 30mg ', 150, 1, 'CONFIRMED', '1292710511'),
(5, 4, 1, 'Bolivian Brick Cocaine by Starbuckss', 585, 1, 'CONFIRMED', '815118574'),
(6, 5, 1, 'Bolivian Brick Cocaine by Starbuckss', 585, 1, 'CONFIRMED', '159177380');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int NOT NULL,
  `product_cat` varchar(100) NOT NULL,
  `product_brand` varchar(100) NOT NULL,
  `product_title` varchar(50) NOT NULL,
  `product_price` int NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, '1', '4', 'Bolivian Brick Cocaine by Starbuckss', 585, '<b> 585$ - 10 Grams </b>\r\n<br>\r\n<b> Product code : LP41W </b>\r\n<br>\r\n<b> Vendor : Starbuckss </b>\r\n\r\n<br>Straight from the brick, no cuts <br>we do not touch the product.\r\n<br>Will come mostly as rock, there <br>may sometimes be small bits of powder but we aim to mostly to send rock\r\n\r\n\r\nOrders are processed by a professional packer wearing fresh latex gloves each day in a secure, clean packing room.<br> Your product goes straight from the brick into professional packaging with the latest stealth. You can be sure your order is processed fast and safely.\r\n', 'cocaine.jpeg', 'cocaine rock pure bolivian coca hq top '),
(2, '1', '3', 'Xanax S903 Green Hulks', 145, '<b> 145$ - 100 Pills </b>\r\n<br>\r\n<b> Product code : ZXCA7 </b>\r\n<br>\r\n<b> Vendor : Bionik </b>\r\n<br>\r\nS903 Green Hulks new fresh Fire product has just arrived ,very strong !\r\n60% Etizolam 40% Alp', 'xan.jpeg', 'S903 green hulks bars xanax'),
(3, '1', '3', '50 Adderalls B974 30mg ', 150, '<b> 150$ - 50 Pills </b>\r\n<br>\r\n<b> Product code : SW39A </b>\r\n<br>\r\n<b> Vendor : Pharmmarket </b>\r\n<br>\r\nPHARMACY GRADE PRESSED ADDERALLS 30MG MADE WITH THE BEST INGREDIENTS TO PERFECTLY PRESSED PILLS THAT LOOK, FEEL, TASTE,  ALMOST INDENTICAL TO THE REAL THING. SO USE WISELY!!\r\n<br>\r\nAdderall is a prescription medicine used to treat the symptoms of hyperactivity and for impulse control. Adderall may be used alone or with other medications.\r\n<br>\r\nAdderall is a central nervous system stimula', 'aderall.jpg', 'adderall pills b974 30mg top price'),
(4, '2', '', 'Driver Licence USA', 500, '<b> 500$ - 1x Physical DL </b>\r\n<br>\r\n<b> Product code : CC58X </b>\r\n<br>\r\n<b> Vendor : fraudbuddy804 </b>\r\n<br>\r\nDriver Licence physical \r\n<br><br>\r\nUNITED STATES ALL 47 STATES\r\n<br><br>\r\n1)Printed in high definition to the best quality cards available <br>\r\n2)Proper multi-spectrum holograms are applied <br>\r\n3)Ultraviolet/Blacklight ink security features are included <br>\r\n4)Scannable 1D+2D Barcodes are included ', 'driver.JPG', 'fake driver licence fake documents counterfeit DL USA'),
(5, '4', '', 'Chase Bank Account ', 225, '<b> 225$ - 1x Chase Bank account </b>\r\n<br>\r\n<b> Product code : DZZ43 </b>\r\n<br>\r\n<b> Vendor : clockwerk </b>\r\n<br>\r\nWhat do you get upon purchase?\r\n<br>\r\n1 - Cookie File <br>\r\n2 - Full info <br>\r\n3 - IP Address <br>\r\n4 - CHASE login details and email login<br>\r\n5 - System information <br>\r\n6 - Balance <b> 2.000-3.000$', 'chase.JPG', 'chase bank account fraud balance money verifed account '),
(6, '1', '5', '35g Lemon Haze', 302, '<b> 302$ - 35 Grams </b>\r\n<br>\r\n<b> Product code : H74UA </b>\r\n<br>\r\n<b> Vendor : Narco24 </b>\r\n', 'mari.jpg', '35 grams lemon haze thc '),
(7, '1', '4', 'Maserati XTC - pressed 300mg', 450, '<b> 450$ - 100 Pills </b>\r\n<br>\r\n<b> Product code : P45CX </b>\r\n<br>\r\n<b> Vendor : HeinekenExpress </b>\r\n<br>\r\nProduct description:\r\nHard pressed XTC pills containing 300mg of 91% pure MDMA. These pills are pressed with cola flavor added to it.\r\n', 'masserati.png', 'ectasy mdma pure molly xtc pills'),
(8, '5', '', 'HQ VISA/MASTER CC + CVV UP TO $3k', 150, '<b> 150$ - 5x CC </b>\r\n<br>\r\n<b> Product code : M1CX5 </b>\r\n<br>\r\n<b> Vendor : CapeCrusader </b>\r\n<br> Format:\r\n\r\n<br>CARD NUMBER\r\n<br>EXPIRY \r\n<br>CVV\r\n<br>NAME\r\n<br>ADDRESS\r\n<br>CITY\r\n<br>ZIP CODE \r\n<br>STATE \r\n<br>PHONE\r\n<br>EMAIL\r\n', 'cc.jpg', 'cc credit card non vbv fraud debit balance money fraud carding'),
(9, '2', '', 'Passport USA', 685, '<b> 685$ - 1x Passport USA </b>\r\n<br>\r\n<b> Product code : 104OP </b>\r\n<br>\r\n<b> Vendor : fraudbuddy804 </b>\r\n<br>\r\n\r\n\r\nphysical passport', 'passport.png', 'passport counterfeit usa documents fraud'),
(10, '1', '5', 'Super Lemon Haze Hash', 217, '<b> 217$ - 20 Grams </b>\r\n<br>\r\n<b> Product code : UHJA7 </b>\r\n<br>\r\n<b> Vendor : EiffelCartel </b>\r\n<br>\r\nProduit:  Lemon Haze Hash\r\n\r\nOrigin : Amsterdam\r\n\r\nDescription :\r\nLemon Haze Hash est un hybride à dominante sativa dont les deux géniteurs sont les parents. L\'espèce est un croisement entre Silver Haze et Lemon Skunk. Le résultat est apprécié des amateurs de sativa et d’indica.\r\n\r\nChez EiffelCartel,\r\nOn parie sur la qualité,\r\nAlors on a décidé de partager nos BONS PLANS avec vous.', 'ash.png', 'Super Lemon Haze Hash'),
(11, '2', '', '10x50s USD 2017 series EZBOLLAHs notes', 290, '<b> 290$ - 10x50$ </b>\r\n<br>\r\n<b> Product code : 91CAX </b>\r\n<br>\r\n<b> Vendor : EZBLLOAHs </b>\r\n<br>\r\n\r\n\r\nThis bills:\r\n<br>+ Passes Pen Test\r\n<br>+ OVI ink\r\n<br>+ Rised Coat\r\n<br>+ Exact Paper Used\r\n<br>+ Unique Serial Numbers (300 different numbers)\r\n<br>+ Correct Serial Number Font\r\n<br>+ Aligned Seals\r\n<br>+ Correct Colors\r\n<br>+ High Quality Prints\r\n<br>+ Micro Printing\r\n<br>+ Watermark\r\n<br>+ Security Thread\r\n\r\n<br>- not pass UV\r\n<br>- not pass any machines', 'money.jpeg', 'money fake counterfeit usd '),
(12, '2', '', 'Physical European ID Card ', 800, '<b> 800$ - 1x Physical ID Card </b>\r\n<br>\r\n<b> Product code : JH44R </b>\r\n<br>\r\n<b> Vendor : fraudbuddy804 </b>\r\n<br>\r\n\r\nID CARD: inside hologram\r\n<br>Italy\r\n<br>Spain\r\n<br>Poland\r\n<br>Netherlands\r\n<br>Belgium \r\n<br>Hungary \r\n<br>Greece\r\n<br>Germany\r\n<br>Bulgaria \r\n<br>Austria \r\n<br>Czech Republic \r\n<br>France ', 'passport1.jpeg', 'id card counterfeit fake documents'),
(13, '1', '4', 'HQ Cocaine', 650, '<b> 650$ - 10 Grams </b>\r\n<br>\r\n<b> Product code : 55CRP </b>\r\n<br>\r\n<b> Vendor : emmaxoxo </b>\r\n<br>\r\n\r\nHQ Cocaine.\r\n\r\n<br>High quality fishscale cocaine.\r\n\r\n<br>Shiny rocks directly off the brick. Excellent quality at a superb price.\r\n\r\n<br>FREE SAME DAY SHIPPING ALL COUNTRIES', 'coca.jpeg', 'coca hq cocaine rock pure lab drug'),
(14, '1', '4', 'Green Clovers XTC - 200mg (NEW DOSAGE)', 320, '<b> 320$ - 100 Pills </b>\r\n<br>\r\n<b> Product code : W17LZ </b>\r\n<br>\r\n<b> Vendor : HeinekenExpress </b>\r\n<br>\r\n\r\nProduct description:\r\nHard pressed XTC pills containing 200mg of 88% pure MDMA.\r\n\r\n\r\nLab results:\r\nThe lab tests revealed that these pills contain 200mg of MDMA. The MDMA used in these pills is tested at 88% purity. No other substances or adulterants were found.\r\n', 'molly.png', 'mdma pure clear hq molly'),
(15, '1', '3', 'Pain killer-Oxycodone', 180, '<b> 180$ - 100 Pills </b>\r\n<br>\r\n<b> Product code : K447A </b>\r\n<br>\r\n<b> Vendor : OneLastGambit </b>\r\n<br>\r\n\r\n~Delivery~ :\r\n<br>\r\nI send from France, within 24-48 hours from receipt of order.\r\nPackaging is of the best quality in order to ensure perfect reception of goods.\r\n<br>\r\nFrance : 1 to 2 days\r\nEurope : 3 to 9 days\r\nWorld  : 7 to 21 days (Usually 9 days)\r\n', 'oxy.jpeg', 'oxy painkillers oxycodone pills cheap price'),
(16, '1', '3', '2mg Xanax Bars', 180, '<b> 180$ - 125 Pills </b>\r\n<br>\r\n<b> Product code : P57AR </b>\r\n<br>\r\n<b> Vendor : OneLastGambit </b>\r\n<br>\r\n\r\nAlprazolam is the active ingredient in Xanax and these bars have been sent off for lab-testing by several customers over the years, for confirmation of alprazolam and nothing else, every result has come back clean and positive!', 'xanax.jpeg', 'xanax bar 2mg pills '),
(17, '1', '1', 'LSD Tabs - Albert Hofmann - 200ug', 220, '<b> 220$ - 150 Tabs </b>\r\n<br>\r\n<b> Product code : 78R3W </b>\r\n<br>\r\n<b> Vendor : dulcecuarentena </b>\r\n<br>\r\nLSD Tabs - Albert Hofmann - 200ug\r\n<br>\r\nThis is the real (white) LSD, there are a lot of fake LSD vendors around please be aware of these.\r\nWe work closely with the chemists that make this product and we lab test all our LSD before putting\r\nit out on the market!\r\n', 'acid.jpeg', 'acid trip sheet Albert Hofmann LSD'),
(18, '1', '1', 'LSD tab acid 250ug NDD', 343, '<b> 343$ - 50 Tabs </b>\r\n<br>\r\n<b> Product code : RAM44 </b>\r\n<br>\r\n<b> Vendor : dulcecuarentena </b>\r\n<br>\r\nThis listing is for 250µg tabs of our self-laid\r\n99.93% pure LSD - “Tears of Joy” on the \"Blue Buddhas\" print.\r\nOur LSD is purified at both stages of synthesis (salt, crystal), yielding\r\nan exceptionally pure product.', 'paper1.jpeg', 'acid trip hq tabs'),
(19, '1', '1', 'Mayan Calander LSD - 300ug', 274, '<b> 274$ - 50 Tabs</b>\r\n<br>\r\n<b> Product code : P52KK </b>\r\n<br>\r\n<b> Vendor : HeinekenExpress </b>\r\n<br>\r\n<br>\r\nProduct description:\r\nDutch made LSD blotters made of the finest LSD crystals we could get our hands on.\r\n\r\n<br>\r\nLab results:\r\nThe blotters are lab tested. They contain 300ug of pure LSD, no other substances or adulterants were found.\r\n\r\n', 'paper2.png', 'tabs lsd hq acid trip '),
(20, '1', '2', 'OPENLINE Ketamine Needles', 275, '<b> 275$ - 14 Grams </b>\r\n<br>\r\n<b> Product code : FH11X </b>\r\n<br>\r\n<b> Vendor : OPENLINE </b>\r\n\r\n<br>DELIVERY INFO\r\n<br>\r\nEvery order gets shipped out within 24 hours (any amount)\r\n100% smell and detection proof\r\nVacuum sealed\r\nWe ship in small envelopes which will fit your mailbox\r\nAll products have maximum stealth\r\n\r\n<br>\r\nEUROPE PRIORITY 2-12 DAYS<br>\r\nASIA PRIORITY 5-24 DAYS<br>\r\nSOUTH AMERICA PRIORITY 7-21 DAYS<br>\r\nCANADA PRIORITY 7-21 DAYS<br>\r\nAFRICA PRIORITY 5-21 DAYS<br>', 'ketamin.jpeg', 'ketamine hq pure crystal lab'),
(21, '4', '', 'PayPal Transfer', 550, '<b> 550$ - 2.500$ Transfer </b>\r\n<br>\r\n<b> Product code : UCA4R </b>\r\n<br>\r\n<b> Vendor : CapeCrusader </b>\r\n<br>\r\nPAYPAL TRANSFER 2.500 USD  <br>Transfer to your PayPal ACC.', 'paypal.JPG', 'paypal transfer fraud money'),
(22, '1', '4', 'Jurassic Park XTC - pressed 250mg ', 380, '<b> 380$ - 100 Pills </b>\r\n<br>\r\n<b> Product code : DP79C </b>\r\n<br>\r\n<b> Vendor : HeinekenExpress </b>\r\n<br>\r\nProduct description:\r\nHard pressed XTC pills containing 250mg of 88% pure MDMA. \r\n<br>\r\n\r\nLab results:\r\nThe lab tests revealed that these pills contain 250mg of MDMA. The MDMA\r\nused in these pills is tested at 88% purity. No other substances or\r\nadulterants were found.\r\n', 'mola.png', 'etcasy molly hq pure '),
(23, '1', '4', 'XTC: Maserati 300MG', 430, '<b> 430$ - 100 Pills </b>\r\n<br>\r\n<b> Product code : HHU14 </b>\r\n<br>\r\n<b> Vendor : Wakikiweedshop </b>\r\n<br>\r\nFREE TRACKING\r\nXTC: Maserati 300MG \r\n<br>\r\nALL STATES \r\nNOT CANADA', 'kar.jpeg', 'xtc ectasy molly pure hq'),
(24, '4', '', 'BOA Account + Balance', 260, '<b> 260$ - 1x BOA Account </b>\r\n<br>\r\n<b> Product code : DO44Z </b>\r\n<br>\r\n<b> Vendor : clockwerk </b>\r\n<br>\r\n\r\nWhat do you get upon purchase?\r\n<br>\r\n1 - Cookie File <br>\r\n2 - Full info <br>\r\n3 - IP Address <br>\r\n4 - CHASE login details and email login<br>\r\n5 - System information <br>\r\n6 - Balance <b> 2.000-3.000$\r\n<br>\r\n\r\n+TUTORIAL', 'boa.jpg', 'boa account fraud money make bank'),
(25, '4', '', 'Cashapp account + balance and cookies', 320, '<b> 320$ - 1x Cashapp account </b>\r\n<br>\r\n<b> Product code : KUOK8 </b>\r\n<br>\r\n<b> Vendor : clockwerk </b>\r\n<br>\r\n\r\n\r\nWhat do you get upon purchase?\r\n<br>\r\n1 - Cookie File <br>\r\n2 - Full info <br>\r\n3 - IP Address <br>\r\n4 - Cashapp login details and email login<br>\r\n5 - user-agent <br>\r\n6 - Balance <b> 2.000-3.000$', 'Cashapp_logo.png', 'fraud cashapp money cookies user agent'),
(26, '1', '5', 'Gelato', 275, '<b> 275$ -  Pills </b>\r\n<br>\r\n<b> Product code : AZ47A </b>\r\n<br>\r\n<b> Vendor : topnotchbud </b>\r\n<br>\r\nGelato is a slightly indica dominant hybrid (55% indica/45% sativa) strain created through a cross of the infamous Sunset Sherbet X Thin Mint Girl Scout Cookies strains.\r\nThis dank bud is infamous for its insanely delicious flavor and hugely powerful effects that are fueled by a THC', 'mara.jpeg', 'marihuana thc '),
(28, '1', '5', 'Pollen Hash', 220, '<b> 220$ - 30 Grams </b>\r\n<br>\r\n<b> Product code : CC4RG </b>\r\n<br>\r\n<b> Vendor : CobraVerde </b>\r\n<br>\r\nOur Hashish is made from fine pollen. It is high quality which you can smell, taste and feel once you have it in your hands.\r\nOrder now and try it out yourself!\r\n<br>\r\nFor international orders the maximum amount that is refund elegible is 5 grams. If you order more then that you do so at your own risk. Absolutely no refunds or reshippings for more then 5 Grams outside of Germany.', 'hash.jpeg', 'hash thc rock brick'),
(29, '1', '2', 'Racemic Ketamine ', 190, '<b> 190$ - 10 Grams </b>\r\n<br>\r\n<b> Product code : R45XC </b>\r\n<br>\r\n<b> Vendor : LySanDerspooner </b>\r\n<br>\r\nClean K hole material. Shards straight from the lab.', 'mam.JPG', 'ketamine shards crystal clean lab'),
(30, '1', '5', 'RAMBO 10/10 SHAKE HASH', 485, '<b> 485$ - 100.00 Grams </b>\r\n<br>\r\n<b> Product code : RY44A </b>\r\n<br>\r\n<b> Vendor : rambouk2uk </b>\r\n<br>\r\nOrders must be placed before 11am to gaurentee Next Day service, orders placed after 11am will be processed the following day. This product is for UK shipping only<br>\r\n\r\nMany thanks,\r\nRambo\r\n<br>\r\nhowdy troops\r\n\r\nBubble/ Isolator made with AAA popcorn and sugar\r\nTrim from our signature Ammie and dawg .This blend\r\nIs both smooth and has a potent aroma all to top off with a\r\nnice buzz. sit Just enjoy. ( PS support UK bubble no additives or\r\nbulking agents that both import and other sources contain).', 'ash1.jpeg', 'shake hash uk hq top'),
(31, '1', '4', '25g Crystal Meth', 1058, '<b> 1058$ - 25 Grams </b>\r\n<br>\r\n<b> Product code : D748A </b>\r\n<br>\r\n<b> Vendor : Narco24 </b>\r\n\r\n25g high qualitiy Crystal Meth.\r\nFor the beginning, we deliberately set the price low, so get your hands on it!', 'med.jpg', 'meth speed crystal germany'),
(32, '1', '4', '** Speed Paste **', 220, '<b> 220$ - 50 Grams </b>\r\n<br>\r\n<b> Product code : 3RD2X </b>\r\n<br>\r\n<b> Vendor : CobraVerde </b>\r\n<br>\r\nThis speedpaste is CLEAN and STRONG. Please try it out and see for yourself!\r\n<br>\r\nAll orders we recieve before 16:00 CEST (Mondays - Saturdays) will be shipped that same day. Domestic orders have a 99.9% chance of next day delivery (except Sundays). Orders from EU Countries outside of Germany usually take 2-3 working days. \r\n<br>\r\nFor international orders the maximum amount that is refund elegible is 5 grams. If you order more then that it is at your own risk. Absolutely no refunds or reshippings for more then 5 Grams outside of Germany.', 'oaste.jpeg', 'paste speed stimulants '),
(33, '1', '4', '**GLOBALCOKEUK\'S TOP SHELF**', 1017, '<b> 1017$ - 20 Grams </b>\r\n<br>\r\n<b> Product code : UED4L </b>\r\n<br>\r\n<b> Vendor : globalcokeuk </b>\r\n<br>\r\nTOP SHELF COLOMBIAN BRICK COCAINE \r\n<br>\r\nOur batches are sourced straight out of Colombia and we sell it directly how it comes in.  It will arrive to you as a flakey oily rock. Colombia is known for having the best sourcing of cocaine.\r\n<br>\r\nIf your rub the product in your finger, you will see it rubs to clear oil which shows the high purity of this product. You wont feel much in your nose when sniffing it because its so pure. No hangovers or come downs, you could go throughout the day taking this stuff and could be normal. \r\n', 'ccc.jpeg', 'cocaine rock best quality hq colombian\r\nbrick'),
(34, '1', '4', 'ICE Speed Pills 40mg', 186, '<b> 186$ - 250 Pills </b>\r\n<br>\r\n<b> Product code : C895P </b>\r\n<br>\r\n<b> Vendor : PenileFractures </b>\r\n<br>\r\nICE speed/meth pills.\r\n<br>\r\nPressed with 40mg. Press is hard and solid.\r\n<br>\r\n\r\nADDRESS FORMAT:\r\n<br>\r\nName <br>\r\nStreet address <br>\r\nCity, Province, Postal code <br>\r\n\r\nExample: <br>\r\nPenile Fractures <br>\r\n1098 Beacon St <br>\r\nOttawa ON M7H 4J5 <br>\r\n\r\n<br>\r\nRead our whole profile before purchasing.', 'meth.jpeg', 'meth speed pills'),
(35, '1', '2', 'OPENLINE Dutch MDMA', 275, '<b> 275$ - 14 Grams </b>\r\n<br>\r\n<b> Product code : O1A2R </b>\r\n<br>\r\n<b> Vendor : OPENLINE </b>\r\n<br>\r\n\r\nDUTCH SYNTHESISED MDMA , NO BULL SHIT FAKE ANALOGUE MARQUIS TEST STRAIGHT TO BLACK\r\n<br>\r\nHIGHEST PURITY ON THE MARKET \r\n<br>\r\nChampagne yellow colour, REAL SHIT', 'em.jpeg', 'dutch mdma krystal pure hq'),
(57, '4', '', 'PayPal Transfer', 300, '<b> 300$ - 1.000$ Transfer </b>\r\n<br>\r\n<b> Product code : S37XH </b>\r\n<br>\r\n<b> Vendor : CapeCrusader </b>\r\n<br>\r\nPAYPAL TRANSFER 1000 USD  <br>Transfer to your PayPal ACC.', 'paypal.JPG', 'paypal transfer fraud money'),
(60, '1', '4', 'Nintendo XTC - pressed 150mg (NEW DOSAGE)', 280, '<b> 280$ - 100 Pills </b>\r\n<br>\r\n<b> Product code : FX35C </b>\r\n<br>\r\n<b> Vendor : HeinekenExpress </b>\r\n<br>\r\nProduct description:\r\nHard pressed XTC pills containing 150mg of 88% pure MDMA.\r\n\r\n<br><br>\r\nLab results:\r\nThe lab tests revealed that these pills contain 150mg of MDMA. The MDMA used in these pills is tested at 88% purity. No other substances or adulterants were found.\r\n\r\n\r\n\r\n', 'nintendo.jpg', 'xtc nintendo mdma ectasy molly '),
(62, '1', '4', 'MDMA CHAMPAGNE', 125, '<b> 125$ - 15 Grams</b>\r\n<br>\r\n<b> Product code : 68HX7 </b>\r\n<br>\r\n<b> Vendor : igrowswiss </b>\r\n<br>\r\n\r\nAppearance and size:\r\nThe MDMA is made of crystals with a champagne like color. In lower amounts it is usually more powder like. Larger amounts contain larger crystals.', 'mdmaa.jpeg', 'mdma crystal pure '),
(63, '1', '5', '5g Sherblato Cannabis', 73, '<b> 72.66$ - 5 Grams </b>\r\n<br>\r\n<b> Product code : GG9AE </b>\r\n<br>\r\n<b> Vendor : Narco24 </b>\r\n<br>\r\n5g high qualitiy Sherblato Cannabis\r\nFor the beginning, we deliberately set the price low, so get your hands on it!', 'thc.jpg', 'thc cannabis model top vendor'),
(65, '1', '5', '15g \"Helle Polle\" Hash', 149, '<b> 148.55$ - 15 Grams </b>\r\n<br>\r\n<b> Product code : WT87A </b>\r\n<br>\r\n<b> Vendor : Narco24 </b>\r\n<br>\r\n\r\n5g high qualitiy \"Helle Polle\" Hash.\r\nFor the beginning, we deliberately set the price low, so get your hands on it!', 'hello.jpg', 'hasish thc helle hash price low'),
(67, '1', '2', '7.5g Ketamine Crystals', 166, '<b> 166$ - 7.5 Grams </b>\r\n<br>\r\n<b> Product code : ACTT7 </b>\r\n<br>\r\n<b> Vendor : Narco24 </b>\r\n7.5g high qualitiy Ketamine Crystals.\r\nFor the beginning, we deliberately set the price low, so get your hands on it!', 'keta.jpg', 'keta ketamine shards '),
(68, '1', '4', '20g High Quality Speed', 122, '<b> 122$ - 20 Grams </b>\r\n<br>\r\n<b> Product code : CC87A </b>\r\n<br>\r\n<b> Vendor : Narco24 </b>\r\n<br>\r\n5g high qualitiy Speed.\r\nFor the beginning, we deliberately set the price low, so get your hands on it!', 'speed.jpg', 'hq top speed low price meth'),
(73, '1', '1', '50x LSD Vendetta 250 microgram', 216, '<b> 216$ - 50 Tabs </b>\r\n<br>\r\n<b> Product code : O74HA </b>\r\n<br>\r\n<b> Vendor : Narco24 </b>\r\n', 'vendeta.jpg', 'vendetta trip acid strong cheap');

-- --------------------------------------------------------

--
-- Table structure for table `received_payment`
--

CREATE TABLE `received_payment` (
  `id` int NOT NULL,
  `uid` int NOT NULL,
  `amt` int NOT NULL,
  `tr_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(1, 'steeve', 'steeve', 'steeve@azuretmarket.com', '4e4d6c332b6fe62a63afe56171fd3725', '1578946214', 'ping', 'any'),
(2, 'buyer664', 'buyer664', 'buyer664@protonmail.com', '126a781628cb25da99768685079c5d95', '1789424784', 'blue', 'any'),
(3, 'dmx302', 'dxm302', 'dmx302@protonmail.com', '4e4d6c332b6fe62a63afe56171fd3725', '1572109873', 'Pink', 'Any'),
(4, 'beefxss', 'beefxss', 'beefxss@protonmail.com', '4e4d6c332b6fe62a63afe56171fd3725', '1697894154', 'any', 'any'),
(5, 'kim12', 'kim12', 'kim12@protonmail.com', '4e4d6c332b6fe62a63afe56171fd3725', '1693570123', 'Blue', 'Any');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `received_payment`
--
ALTER TABLE `received_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `received_payment`
--
ALTER TABLE `received_payment`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
