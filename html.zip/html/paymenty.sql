-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 11, 2021 at 08:05 PM
-- Server version: 8.0.26-0ubuntu0.20.04.2
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paymenty`
--

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int NOT NULL,
  `code` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `price` double NOT NULL,
  `status` int NOT NULL,
  `product` int NOT NULL,
  `ip` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `code`, `address`, `price`, `status`, `product`, `ip`) VALUES
(1, 'KwUwysW3R5ZhYrggLrn2t3fVr', '33QVhG6r5tWdj6JFeSttk1Jer7xUh7fcDz', 300, -1, 8, '127.0.0.1'),
(2, 'Atpbgy0C1hn9HAx7xx3Cw97KP', '34UswnG3jLa5EHaNGhB681avEhhwcd8z4o', 275, -1, 54, '127.0.0.1'),
(3, 'eTfK6jINDsBqftPSbvwTT6rhb', '3Gvnrrgk7oyaMStNewcGCfnnNSjqqkpxYa', 275, -1, 54, '127.0.0.1'),
(4, 'Du70mjEodR7ldGqPOfoVq7ofX', '3AMQzpVAnU8ErVRoFdj3A51pL5SXHYTM6L', 186, -1, 50, '127.0.0.1'),
(5, 'fMo94C2icvjvJqkcGsUBPi4j8', '3CttXzJcziCboDhvHv1TKN17kowHdobZpE', 430, -1, 48, '127.0.0.1'),
(6, 'bg7nqKuvlzCq8jrlzpScEnxAq', '3CD4uN6qfbnZxNQTdJeguL53FPvCxt8Rwn', 1017, -1, 47, '127.0.0.1'),
(7, 'F6oWvl0n7tML9z3jzIXjnInjy', '3L1yQXjusb8HwAA7xagJaGFXK55ksQnWbj', 1058, -1, 46, '127.0.0.1'),
(8, 'E5Lqop2hBVper2iUOE1Iyqkew', '34dGia7oa4aeMEdLmCFDDUAcuzDA4gv8MR', 220, -1, 44, '127.0.0.1'),
(9, 'wesKhm0iU8HMWsReoeB0SGHPn', '33eSiUqpS3ZchZPCpWXMPFqY98NjfKcETQ', 145, -1, 40, '127.0.0.1'),
(10, 'MazV3FhAOwb6svXwj3xzkTaIm', '3NXJXhk73Mwnsb3h2CdDS3GJEWRGGryfs4', 220, -1, 38, '127.0.0.1'),
(11, 'IbWvEoYFFnLRp559QgKLQd9Gp', '3Jdp9NouMMD3PRiNnZ9NYPH4cNUSU7k8Tm', 485, -1, 35, '127.0.0.1'),
(12, 'ZL25o5Ot6XakbESFdcG3LKgTm', '3M8tvRkY2AcMpy7rjhVvP1mB9WytuGsGsn', 217, -1, 34, '127.0.0.1'),
(13, '0T6uGB25TjrBq5gAPtNEKMII0', '3HP5fTzrySLWVHCdk3x3vaK4nS7HYVDqdA', 275, -1, 33, '127.0.0.1'),
(14, 'lMywtYSYstonKFNYzLHwXRuie', '37yWnAMejZLP7RT2gfstawgbpe15hyb4Hk', 500, -1, 32, '127.0.0.1'),
(15, 'k51IcOr5LkrEY5ourHITeIGog', 'HTTP/1.1 500 Internal Server Error\n{\"status\": 500, \"message\": \"Gap limit exceeded. Mostly this is a temporary error. Just try again\", \"error_code\": 1006}', 320, -1, 31, '127.0.0.1'),
(16, 'pVS9BxuSET11vnQRlx4w0oDxr', '3GzByaaJJ6GJDuDzQrM7WgpX6tL4gyfxFd', 260, -1, 30, '127.0.0.1'),
(17, '5X9CTjedhgNssGqdgQ1kx3Enw', '3HCSuQ21FygLEFRrQdnHxydHbzzUpxA5i9', 450, -1, 29, '127.0.0.1'),
(18, '7QGJbbLv1X376aXCVRaEm2noJ', '36GRa8jsGrgDAkLo6bwyQKeXUpiEuJH9RU', 380, -1, 28, '127.0.0.1'),
(19, 'NpP46hHdUk1nKEoaasiBZAy7V', '3KdRH3jbRe4YEEF4nnoxyMmtnxDs9Yu1QL', 550, -1, 27, '127.0.0.1'),
(20, 'BgfrCpyzWDclS6zEOId4deesF', '38PhjNoKvVpeH2HWC3JggThxUy9STH7BaC', 275, -1, 26, '127.0.0.1'),
(21, 'Bp1G1dnZFmyFIbZLfcKaIE73A', '37CP6MwKWVaa4E7nko5WsQRoNyme9wGREr', 274, -1, 25, '127.0.0.1'),
(22, 'KQUogf2RoHCJC0F49tjbSSGrx', '3FCWJdBkegVoSwBfZg5d5xdc1EgWg3zyUX', 343, -1, 24, '127.0.0.1'),
(23, '1xy5HjYx3CamXIEpHGyCl6Sbr', '3NMm84cG4TkjWoi56MUXUuuXF8VqWwKFmy', 220, -1, 23, '127.0.0.1'),
(24, 'Idfwm4KtbKLBg3rqHgbMt7TjH', '3Hyye9vkgL8mhCheNofqTX68KVYFtwVG5i', 180, -1, 22, '127.0.0.1'),
(25, 'yPsqhqiZc9VpJ4yOV7zWuMLCc', '3BaJ9XDKiPv8UvDuzccdhstbyQBdfrjok9', 180, -1, 19, '127.0.0.1'),
(26, 'YX3Zw4dMrLAUN22S8yeN6CZdt', '3FY7sfA3vBkZxDKGiJbYmV6puFUQwouJpG', 320, -1, 18, '127.0.0.1'),
(27, 'Jj64ZmL2u3d2gSCSMmPjLF17w', '3JBQCFBrC7gnsw497uMn2MPNPJy3VDd5co', 650, -1, 17, '127.0.0.1'),
(28, 'z1CpseedI6lBeLMcC53GmDHAd', '3FQXEMf5JL4wk33rPwWibPJuakHaCAJdCN', 800, -1, 14, '127.0.0.1'),
(29, 'Hts3gurj80kIxEaSzc75zQZMK', '3EiKQNxmMYmZFXTLJ4aehEvGKb7JSihLiq', 290, -1, 13, '127.0.0.1'),
(30, 'AzpIP8exJayxV0X9VT5lN6v5K', '392RASYxJD5o5E5na44zpDCWKxQiwHqZ97', 585, -1, 12, '127.0.0.1'),
(31, 'ptzFcr7FelBoxTjddVhPCzx5E', '3Bj4jJvWxvPJWSL7wD3a2q2zdFWXGDqcX6', 685, -1, 11, '127.0.0.1'),
(32, 'gLIcWA1BvYBIRcHdEC4aLDQJa', '3LXcxAAJmz4QDmASN5ZvcyDD7NyFyJoE1Y', 150, -1, 10, '127.0.0.1'),
(33, 'ayqMtghHi2K7chdshQShGwFPM', '3AJUyMacBeM67RjzRC4E62KbApnGUGwkxV', 300, -1, 8, '127.0.0.1'),
(34, 'XfQC2Q2IVYfl7WkWUQWwEMu3D', '35zuXsRMvyAkq1oqdLzqxoVVyYUAsrfxKA', 190, -1, 6, '127.0.0.1'),
(35, 'nSU3NhpBBefWmcKdE3g4kYdqI', '37HhZZfrPFECyairg2AfeLijHbRXJhpkpD', 225, -1, 5, '127.0.0.1'),
(36, 'EjKZ5oyf3UmN3zGfbFLDe2ln7', '3MoTU5QALcYayNKKkpQVEjvZsC3auuAc3r', 125, -1, 3, '127.0.0.1'),
(37, '0aIfBh56TP4PX0KM6kI4GXTVD', '3FGKRtUByH3ThVJ6ZH8JgUGHgMRjekA8AL', 280, -1, 2, '127.0.0.1'),
(38, 'JprPAAoR7FIQQcu6MuGFd95eE', '3HZAABQtHGEzAG8DAb28zRA1c7gvnZqGdc', 302, -1, 71, '127.0.0.1'),
(39, 'r2AlGWxS56J4oPeU78MeW5mDm', 'bc1qa54rxhsr7avl7w2pqfstzwjmc3rdvcz0pcf5xk', 1, -1, 84, '127.0.0.1'),
(40, 'VJN89VQI0Fu381wmv6AKd2RQl', 'bc1q6duc8q7le6ng6hlh6q0n5u94kh2wrjt2nnlup6', 166, -1, 77, '127.0.0.1'),
(41, 'sI54T8gFwZ8eqB9fO7ibqMrnq', 'bc1qmgtn5clw56tfdntcxh4kvkvjarqyyghuljapyw', 72.66, -1, 64, '127.0.0.1'),
(42, 'PMlBH3XDI218L3MvRDrhObhHg', 'bc1qrrft934kt9dzd5c8geerjdwekmkf6h5sk9eqp2', 1017, -1, 47, '127.0.0.1'),
(43, 'Gl6Z2YXZO0BxsswqRWSwN4IGz', 'bc1qwhq8cnvvrhjcpetsdc8287jmv9hnpgp38p90zk', 1, -1, 84, '127.0.0.1'),
(44, 'RzM54uTnrddrqlysQZxzbfopn', 'bc1qk0pxsznj80l9whjafs0w36pd3edv4gum87fhf5', 1, -1, 84, '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `invoice` varchar(256) NOT NULL,
  `ip` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int NOT NULL,
  `txid` varchar(256) NOT NULL,
  `addr` varchar(256) NOT NULL,
  `value` int NOT NULL,
  `status` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` longtext NOT NULL,
  `price` float(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`) VALUES
(2, 'Nintendo XTC ', '<b> Product code : FX35C </b>\r\n', 280.00),
(3, 'MDMA CHAMPAGNE', '<b> Product code : 68HX7 </b>', 125.00),
(5, 'Chase Bank Account', '<b> Product code : DZZ43 </b>', 225.00),
(6, 'Racemic Ketamine ', '<b> Product code : R45XC </b>', 190.00),
(8, 'PayPal Transfer', '<b> Product code : S37XH </b>', 300.00),
(10, 'HQ VISA/MASTER CC', '<b> Product code : M1CX5 </b>', 150.00),
(11, 'Passport USA', '<b> Product code : 104OP </b>', 685.00),
(12, 'Bolivian Brick Cocaine ', '<b> Product code : LP41W </b>', 585.00),
(13, '10x50s USD 2017', '<b> Product code : 91CAX </b>', 290.00),
(14, 'Physical European ID Card', '<b> Product code : JH44R </b>', 800.00),
(17, 'HQ Cocaine', '<b> Product code : 55CRP </b>', 650.00),
(18, 'Green Clovers XTC - 200mg', '<b> Product code : W17LZ </b>', 320.00),
(19, 'Pain killer-Oxycodone', '<b> Product code : K447A </b>', 180.00),
(22, '2mg Xanax Bars', '<b> Product code : P57AR </b>', 180.00),
(23, 'LSD Tabs - Albert Hofmann ', '<b> Product code : 78R3W </b>', 220.00),
(24, 'LSD tab acid 250ug NDD', '<b> Product code : RAM44 </b>', 343.00),
(25, 'Mayan Calander LSD', '<b> Product code : P52KK </b>', 274.00),
(26, 'OPENLINE Ketamine ', '<b> Product code : FH11X </b>', 275.00),
(27, 'PayPal Transfer', '<b> Product code : UCA4R </b>', 550.00),
(28, 'Jurassic Park XTC', '<b> Product code : DP79C </b>', 380.00),
(29, 'Maserati XTC - 300mg', '<b> Product code : P45CX </b>', 450.00),
(30, 'BOA Account + Balance', '<b> Product code : DO44Z </b>', 260.00),
(31, 'Cashapp account ', '<b> Product code : KUOK8 </b>', 320.00),
(32, 'Driver Licence USA', '<b> Product code : CC58X </b>', 500.00),
(33, 'Gelato', '<b> Product code : AZ47A </b>', 275.00),
(34, 'Super Lemon Haze Hash', '<b> Product code : UHJA7 </b>', 217.00),
(35, 'RAMBO 10/10 SHAKE', '<b> Product code : RY44A </b>', 485.00),
(38, 'Pollen Hash', '<b> Product code : CC4RG </b>', 220.00),
(40, 'Xanax S903 Green Hulks', '<b> Product code : ZXCA7 </b>', 145.00),
(44, '** Speed Paste **', '<b> Product code : 3RD2X </b>', 220.00),
(46, '25g Crystal Meth', '<b> Product code : D748A </b>', 1058.00),
(47, 'GLOBALCOKEUK\'S TOP ', '<b> Product code : UED4L </b>', 1017.00),
(48, 'XTC: Maserati 300MG', '<b> Product code : HHU14 </b>', 430.00),
(50, 'ICE Speed Pills 40mg', '<b> Product code : C895P </b>', 186.00),
(54, 'OPENLINE Dutch MDMA', '<b> Product code : O1A2R </b>', 275.00),
(62, '50 Adderalls B974 30mg ', '<b> Product code : SW39A </b>', 150.00),
(64, '5g Sherblato Cannabis', '<b> Product code : GG9AE </b>', 72.66),
(68, '15g \"Helle Polle\" Hash', '<b> Product code : WT87A </b>', 148.55),
(69, '20g High Quality Speed', '<b> Product code : CC87A </b>', 122.00),
(71, '35g Lemon Haze', '<b> Product code : H74UA </b>', 302.00),
(74, '50x LSD Vendetta ', '<b> Product code : O74HA </b>', 216.00),
(77, '7.5g Ketamine Crystals', '<b> Product code : ACTT7 </b>', 166.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=281;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
