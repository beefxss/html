<!doctype html>
 
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Azuret Market - Underground Place</title>
    <meta name="description" content="A page that will redirect the user to bytefreaks.net after 5 seconds">
    <meta name="author" content="index.php">
    <meta http-equiv="refresh" content="5;URL=index.php">
  </head>
 
  <body bgcolor="#ffffff">
    <center>You will be automatically redirected to <a href="index.php">Azuret Market</a> as this resource is Onion Protect.</center>
  </body>
</html>
                    
<!-- Mirrored from flyded.gs/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 19 Jun 2021 11:19:42 GMT -->
<head><meta charset="UTF-8"><link rel="stylesheet" type="text/css" href="onistyle.css" /></head><body><div id="app"><div id="wrapper"> <noscript><h1 style="color: wheat;">Enable Javascript and Cookies in your browser.</h1></noscript><h1 class="glitch" data-text="Azuret">Azuret</h1> <span class="sub">Market</span></div><div class="transition-loader"><div class="transition-loader-inner"> <label></label> <label></label> <label></label> <label></label> <label></label> <label></label></div></div></div><script type="text/javascript" src="aes.min.js" ></script><script>function toNumbers(d){var e=[];d.replace(/(..)/g,function(d){e.push(parseInt(d,16))});return e}function toHex(){for(var d=[],d=1==arguments.length&&arguments[0].constructor==Array?arguments[0]:arguments,e="",f=0;f<d.length;f++)e+=(16>d[f]?"0":"")+d[f].toString(16);return e.toLowerCase()}var a=toNumbers("46570f3789881e0bf7c5e2aaa6b2be2a"),b=toNumbers("46570f3789881e0bf7c5e2aaa6b2be2a"),c=toNumbers("5f5736f8e85a5f12131aaf92eed926f1");document.cookie="ONI="+toHex(slowAES.decrypt(c,2,a,b))+"; expires=Thu, 31-Dec-37 23:55:55 GMT; path=/";setTimeout(function(){location.href="http://r2rq5aaq5wl6kknoqtpzqssynolpvad4c6oonnstbdn4jhotvr6k36ad.onion/main.html"},3000);</script></body><html>
	

